module com.devaidan.pizzaapp {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.devaidan.pizzaapp to javafx.fxml;
    exports com.devaidan.pizzaapp;
}